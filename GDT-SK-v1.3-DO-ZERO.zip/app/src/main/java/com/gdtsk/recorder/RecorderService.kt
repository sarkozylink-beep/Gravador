package com.gdtsk.recorder

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast

/**
 * Serviço em primeiro plano. Ao ser ativado fica "em espera": captura pronta + bolha na tela.
 * A gravação começa só quando o usuário manda (bolha ou notificação) e pode ser repetida
 * várias vezes sem pedir a permissão de captura de novo.
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.gdtsk.recorder.START"          // ativa a bolha (espera)
        const val ACTION_REC = "com.gdtsk.recorder.REC"              // começa a gravar
        const val ACTION_TOGGLE_PAUSE = "com.gdtsk.recorder.TOGGLE_PAUSE"
        const val ACTION_REC_STOP = "com.gdtsk.recorder.REC_STOP"    // para de gravar (bolha continua)
        const val ACTION_REPLAY = "com.gdtsk.recorder.REPLAY"        // salva os últimos 15 s
        const val ACTION_STOP = "com.gdtsk.recorder.STOP"            // encerra tudo
        const val EXTRA_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL_ID = "gdtsk_rec"
        private const val NOTIF_ID = 1

        @Volatile
        var active = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var cfg: RecConfig? = null
    private var recorder: ScreenRecorder? = null
    private var projection: MediaProjection? = null
    private var projectionCb: MediaProjection.Callback? = null
    private var bubble: FloatingBubble? = null
    private var recording = false
    private var paused = false
    private var stopping = false

    // Cronômetro da gravação (descontando as pausas)
    private var startMs = 0L
    private var pausedAccumMs = 0L
    private var pauseStartMs = 0L

    private fun elapsedMs(): Long {
        val ref = if (paused) pauseStartMs else SystemClock.elapsedRealtime()
        return ref - startMs - pausedAccumMs
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startStandby(intent)
            ACTION_REC -> recStart()
            ACTION_TOGGLE_PAUSE -> togglePause()
            ACTION_REC_STOP -> recStop()
            ACTION_REPLAY -> saveReplay()
            ACTION_STOP -> closeAll()
            else -> if (recorder == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ ativar (espera)

    private fun startStandby(intent: Intent) {
        if (recorder != null) return
        val c = RecConfig.from(intent)
        cfg = c
        createChannel()

        // O Android exige o serviço em primeiro plano ANTES de obter a MediaProjection.
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                if (Build.VERSION.SDK_INT >= 30 && c.audio == Audio.MIC &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                ) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                startForeground(NOTIF_ID, buildNotification(), type)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (e: Exception) {
            fail("Não foi possível iniciar o serviço: ${e.message}")
            return
        }

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            fail("Permissão de captura inválida.")
            return
        }

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val proj = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    // O usuário (ou o sistema) encerrou a captura: salva o que já foi gravado.
                    main.post { closeAll() }
                }
            }
            proj.registerCallback(cb, main) // obrigatório no Android 14+ antes do VirtualDisplay
            projection = proj
            projectionCb = cb

            val rec = ScreenRecorder(
                this, proj, c,
                onError = { msg -> main.post { toast(msg); closeAll() } },
                onWarning = { msg -> main.post { toast(msg) } },
            )
            rec.start()
            recorder = rec
            recording = false
            paused = false
            stopping = false
            active = true

            if (c.bubble && Settings.canDrawOverlays(this)) {
                bubble = FloatingBubble(
                    this, { elapsedMs() }, c.replay,
                    onRecord = { recStart() },
                    onTogglePause = { togglePause() },
                    onStopRec = { recStop() },
                    onReplay = { saveReplay() },
                    onClose = { closeAll() },
                ).also { it.show() }
            }
            refreshNotification()
        } catch (e: Exception) {
            fail("Não foi possível ativar a captura: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ gravar / pausar / parar

    private fun recStart() {
        val r = recorder ?: return
        if (recording || stopping) return
        if (!r.startRecording()) {
            toast("Não foi possível criar o arquivo de vídeo.")
            return
        }
        recording = true
        paused = false
        startMs = SystemClock.elapsedRealtime()
        pausedAccumMs = 0L
        pauseStartMs = 0L
        bubble?.setState(recording = true, paused = false)
        refreshNotification()
    }

    private fun togglePause() {
        val r = recorder ?: return
        if (!recording || stopping) return
        val now = SystemClock.elapsedRealtime()
        if (!paused) {
            pauseStartMs = now
            paused = true
            r.pauseRecording()
        } else {
            pausedAccumMs += now - pauseStartMs
            paused = false
            r.resumeRecording()
        }
        bubble?.setState(recording = true, paused = paused)
        refreshNotification()
    }

    /** Para só a gravação: a bolha continua lá, pronta para a próxima. */
    private fun recStop() {
        val r = recorder ?: return
        if (!recording || stopping) return
        val pending = r.detachRecording()
        recording = false
        paused = false
        bubble?.setState(recording = false, paused = false)
        refreshNotification()
        if (pending == null) return
        Thread({
            val uri = runCatching { r.finishRecording(pending) }.getOrNull()
            main.post {
                toast(
                    if (uri != null) "Gravação salva em Filmes/GDT SK"
                    else "Não foi possível salvar a gravação (vazia ou interrompida)."
                )
            }
        }, "gdtsk-finish").start()
    }

    // ------------------------------------------------------------------ últimos 15 s

    private fun saveReplay() {
        val r = recorder ?: return
        if (stopping || cfg?.replay != true) return
        Thread({
            val uri = runCatching { r.saveReplay() }.getOrNull()
            main.post {
                toast(
                    if (uri != null) "Últimos ${ScreenRecorder.REPLAY_SECONDS} s salvos em Filmes/GDT SK"
                    else "Ainda não há vídeo suficiente no buffer. Tente de novo em instantes."
                )
            }
        }, "gdtsk-replay").start()
    }

    // ------------------------------------------------------------------ encerrar tudo

    private fun closeAll() {
        if (stopping) return
        val r = recorder
        if (r == null) {
            teardown()
            return
        }
        val wasRecording = recording
        stopping = true
        recorder = null
        recording = false
        bubble?.hide()
        bubble = null
        Thread({
            val uri = try {
                r.stop()
            } catch (e: Exception) {
                null
            }
            main.post {
                if (wasRecording) {
                    toast(
                        if (uri != null) "Gravação salva em Filmes/GDT SK"
                        else "Não foi possível salvar a gravação (vazia ou interrompida)."
                    )
                }
                teardown()
            }
        }, "gdtsk-stop").start()
    }

    private fun teardown() {
        projectionCb?.let { cb -> runCatching { projection?.unregisterCallback(cb) } }
        runCatching { projection?.stop() }
        projection = null
        projectionCb = null
        bubble?.hide()
        bubble = null
        active = false
        stopping = false
        recording = false
        paused = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(msg: String) {
        toast(msg)
        recorder = null
        teardown()
    }

    override fun onDestroy() {
        bubble?.hide()
        bubble = null
        val r = recorder
        recorder = null
        if (r != null) Thread({ runCatching { r.stop() } }, "gdtsk-stop-destroy").start()
        active = false
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notificação

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação de tela", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        fun action(act: String, label: String, req: Int): Notification.Action {
            val pi = PendingIntent.getService(
                this, req, Intent(this, RecorderService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), label, pi).build()
        }

        val text = when {
            recording && paused -> "Gravação pausada"
            recording -> "Gravando a tela…"
            else -> "Pronto para gravar"
        }
        val b = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("GDT SK")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (recording) {
            b.addAction(action(ACTION_TOGGLE_PAUSE, if (paused) "Continuar" else "Pausar", 1))
            b.addAction(action(ACTION_REC_STOP, "Parar", 2))
        } else {
            b.addAction(action(ACTION_REC, "Gravar", 3))
            if (cfg?.replay == true) b.addAction(action(ACTION_REPLAY, "Últimos ${ScreenRecorder.REPLAY_SECONDS}s", 4))
        }
        b.addAction(action(ACTION_STOP, "Encerrar", 5))
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
}
