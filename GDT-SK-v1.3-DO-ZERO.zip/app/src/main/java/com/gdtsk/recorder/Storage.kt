package com.gdtsk.recorder

import android.content.ContentValues
import android.content.Context
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Cria o arquivo MP4 direto na galeria (Filmes/GDT SK).
 * Android 10+: MediaStore (sem permissão). Android 8/9: pasta pública + permissão de escrita.
 * Cada gravação é um arquivo próprio: uma falha numa gravação nunca afeta as já salvas.
 */
object Storage {

    class Output(
        private val ctx: Context,
        val muxer: MediaMuxer,
        private val uri: Uri?,
        private val file: File?,
        private val pfd: ParcelFileDescriptor?,
    ) {
        /** Fecha o arquivo. keep=true publica na galeria; keep=false apaga. */
        fun close(keep: Boolean): Uri? {
            runCatching { pfd?.close() }
            if (uri != null) {
                return if (keep) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    runCatching { ctx.contentResolver.update(uri, v, null, null) }
                    uri
                } else {
                    runCatching { ctx.contentResolver.delete(uri, null, null) }
                    null
                }
            }
            val f = file ?: return null
            return if (keep) {
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf("video/mp4"), null)
                Uri.fromFile(f)
            } else {
                f.delete()
                null
            }
        }
    }

    fun open(ctx: Context, prefix: String = "GDTSK_"): Output {
        val name = prefix + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GDT SK")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = ctx.contentResolver.insert(collection, values)
                ?: throw IllegalStateException("Não foi possível criar o arquivo na galeria.")
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("Não foi possível abrir o arquivo para escrita.")
            val muxer = try {
                MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            } catch (e: Exception) {
                runCatching { pfd.close() }
                runCatching { ctx.contentResolver.delete(uri, null, null) }
                throw e
            }
            return Output(ctx, muxer, uri, null, pfd)
        }

        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "GDT SK")
        if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Não foi possível criar a pasta de vídeos.")
        val f = File(dir, name)
        val muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        return Output(ctx, muxer, null, f, null)
    }
}
